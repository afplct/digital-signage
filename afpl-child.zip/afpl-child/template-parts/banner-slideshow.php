<!--begin #featured-event-slideshow-->
<div id="featured-event-slideshow">

<!--////////////////////////////////-->
<!--//////////begin events//////////-->
<!--////////////////////////////////-->
<?php

global $featured_events;
global $post;
//var_dump($featured_events);

foreach ( $featured_events['top_banner'] as $post ): setup_postdata($post);

$pod = pods('tribe_events', get_the_ID());
$event_featured_heading = $pod->display('event_featured_heading');

//begin event flag
$eventDate = strtotime(tribe_get_start_date($post->ID, false, 'Y-m-d'));
$today = new DateTime('today');
$todaysDate = $today->getTimestamp();
$tomorrow = new DateTime('tomorrow');
$tomorrowsDate = $tomorrow->getTimestamp();
$event_flag = '';
if ($eventDate == $todaysDate){
    $event_flag = '<div class="event-flag">Today!</div>';
}
if ($eventDate == $tomorrowsDate){
    $event_flag = '<div class="event-flag">Tomorrow!</div>';
}
//end event flag

?>

    <!--begin .front-page-banner-->
    <div class="front-page-banner featured-event-slideshow-slide">
        <div id="today-event">Today</div>


    <!--begin featured image-->
    <?php if ( has_post_thumbnail()) : ?>
    <div class="img-container">
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
            <?php the_post_thumbnail('small', ['class' => 'front-page-banner-image']); ?>
        </a>
    </div>
    <?php endif; ?>
    <!--end featured image-->

        <!--begin .front-page-banner-info-->
        <div class="front-page-banner-info">
            <?php echo ($event_featured_heading != "") ? '<div class="featured-heading">'.$event_featured_heading.'</div>' : ''; ?>
            <?php echo $event_flag; ?>

        <?php
        echo '<h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
        echo '<div class="event-schedule-details">' . tribe_events_event_schedule_details() .'</div>';
        the_excerpt();

        echo '<a href="' . get_permalink() . '" class="button more">More</a>';

        ?>

        </div>
        <!--end .front-page-banner-info-->

    </div>
    <!--end .front-page-banner . featured-event-slideshow-slide-->

<?php endforeach; wp_reset_postdata();?>

<?php

foreach ( $featured_events['banner'] as $post ): setup_postdata($post);

$pod = pods('tribe_events', get_the_ID());
$event_featured_heading = $pod->display('event_featured_heading');

//begin event flag
$eventDate = strtotime(tribe_get_start_date($post->ID, false, 'Y-m-d'));
$today = new DateTime('today');
$todaysDate = $today->getTimestamp();
$tomorrow = new DateTime('tomorrow');
$tomorrowsDate = $tomorrow->getTimestamp();
$event_flag = '';
if ($eventDate == $todaysDate){
    $event_flag = '<div class="event-flag">Today!</div>';
}
if ($eventDate == $tomorrowsDate){
    $event_flag = '<div class="event-flag">Tomorrow!</div>';
}
//end event flag

?>

    <!--begin .front-page-banner . featured-event-slideshow-slide-->
    <div class="front-page-banner  featured-event-slideshow-slide">

    <!--begin featured image-->
    <?php if ( has_post_thumbnail()) : ?>
    <div class="img-container">
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
            <?php the_post_thumbnail('small', ['class' => 'front-page-banner-image']); ?>
        </a>
    </div>
    <?php endif; ?>
    <!--end featured image-->

        <!--begin .front-page-banner-info-->
        <div class="front-page-banner-info">
            <?php echo ($event_featured_heading != "") ? '<div class="featured-heading">'.$event_featured_heading.'</div>' : ''; ?>
            <?php echo $event_flag; ?>

        <?php
        echo '<h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
        echo '<div class="event-schedule-details">' . tribe_events_event_schedule_details() .'</div>';
        the_excerpt();

        echo '<a href="' . get_permalink() . '" class="button more">More</a>';

        ?>

        </div>
        <!--end .front-page-banner-info-->

    </div>
    <!--end .front-page-banner .featured-event-slideshow-slide-->

<?php endforeach; wp_reset_postdata();?>

<!--//////////////////////////////-->
<!--//////////end events//////////-->
<!--//////////////////////////////-->

<script type="text/javascript">
  showSlides(featured-event-slideshow)
</script>

</div>
<!--end #featured-event-slideshow-->
