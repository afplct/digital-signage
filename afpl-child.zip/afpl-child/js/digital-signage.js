
//Slideshow
var slideIndex = 0;
var slideshow;
showSlides();

function showSlides(slideshow, time) {
    timer: 10000; //default = 10 seconds

    //if custom time is set, convert seconds to milliseconds
    if (time) {
      timer = time * 1000;
    }

    //run slideshow
    var i;
    var slides = document.getElementsByClassName(slideshow + "-slide");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}
    slides[slideIndex-1].style.display = "block";
    setTimeout(showSlides(slideshow), 10000); // Change image every 10 seconds
}



//Current Date and Time
var tday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
var tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate();
var nhour=d.getHours(),nmin=d.getMinutes(),ap;
if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nmin<=9) nmin="0"+nmin;

document.getElementById('clockbox').innerHTML=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+" "+nhour+":"+nmin+ap+"";
}

window.onload=function(){
  GetClock();
setInterval(GetClock,1000);
}


}


//Local weather
function showLocalWeather() {
  !function(d,s,id) {
    var js,
    fjs=d.getElementsByTagName(s)[0];

    if(!d.getElementById(id)) {
      js=d.createElement(s);
      js.id=id;
      js.src='https://weatherwidget.io/js/widget.min.js';
      fjs.parentNode.insertBefore(js,fjs);}
    }

    (document,'script','weatherwidget-io-js');
}
