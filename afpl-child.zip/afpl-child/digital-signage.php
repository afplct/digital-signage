<?php /* Template Name: Digital Signage */
/*
 * This is the template for pages displayed on digital signage.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Avon_Free_Public_Library
 */

?>

<!--BEGIN modified header.php code-->
<?php



global $featured_events;
$tz = 'America/New_York';
$start = time();
$end = strtotime('+180 days', $start);
$dt = new DateTime('now', new DateTimeZone($tz));
$dt->setTimestamp($start);
$start_date = $dt->format('Y-m-d H:i:s');
$dt->setTimestamp($end);
$end_date = $dt->format('Y-m-d H:i:s');

$featured_events['banner'] = tribe_get_events(
    array(
        'eventDisplay' => 'custom',
        'start_date'     => $start_date,
        'end_date'     => $end_date,
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'ASC',
        'tribeHideRecurrence' => 'true',
        'meta_query'     => array(
            array(
                'key'   => 'homepage_feature_type',
                'value' => array('top_banner', 'banner', 'list'),
                'meta_compare' => '='
            )
        )
    )
);

$base_banners = 10; // max banners to show on digital signage
$max_banners = 10; // max top_banners and banners to show on digital signage
$min_start_interval = 3; //min days before next event start date to show on homepage
$today = new DateTime('today'); //for use in DateTime::diff
$featured_events['top_banner'] = array(); //setup empty array
global $post;

//get banners (slides)

foreach($featured_events['banner'] as $key => $post){
    setup_postdata($post);
    $event_start_date = new DateTime($post->EventStartDate);
    $start_interval = $today->diff($event_start_date)->format('%a'); //days before next event start
    if($banner_count < $base_banners || ($start_interval < $min_start_interval && $banner_count < $max_banners)){
        $banner_count++;
    } else {
        unset($featured_events['banner'][$key]);
    }
}

wp_reset_postdata();

?>

    <!DOCTYPE html>
    <html <?php language_attributes(); ?>>

    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="//gmpg.org/xfn/11">

        <?php wp_head(); ?>
        <script src="foo.js"></script><!--prevents weird css transition behavior on IE-->
        <script type="text/javascript">

        </script>
    </head>

    <body <?php body_class(); ?>>
        <div id="page" class="site">
            <a class="skip-link screen-reader-text" href="#content-dig-sign">
                <?php esc_html_e( 'Skip to content', 'afpl' ); ?>
            </a>

            <header id="masthead" class="site-header" role="banner">
                <div class="site-branding-container">
                <div class="width-container">

                <div class="site-branding">
                    <?php
			if ( is_front_page() && is_home() ) : ?>
                        <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                        <?php else : ?>
                            <p class="site-title">
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                                    <?php bloginfo( 'name' ); ?>
                                </a>
                            </p>
                            <?php
			endif;

			$description = get_bloginfo( 'description', 'display' );
			if ( $description || is_customize_preview() ) : ?>
                                <p class="site-description">
                                    <?php echo $description; /* WPCS: xss ok. */ ?>
                                </p>
                                <?php

endif; ?>




                </div>
                <!-- .site-branding -->
                </div> <!-- width-container -->
                </div>
                <!-- .site-branding-container -->

            </header>
            <!-- #masthead -->



            <!-- #content -->
            <div id="content-dig-sign" class="site-content">

<?php

//var_dump($featured_events);
?>
<!--END modified header.php code-->

<?php
    get_template_part( 'template-parts/banner', 'slideshow' );
?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">




        </main>
        <!-- #main -->
    </div>
    <!-- #primary -->

<!--BEGIN modified footer.php code-->
  </div>
  <!-- #content -->



          <!-- #colophon -->

          </div>
          </div>
          <!-- #page -->

          <?php wp_footer(); ?>

              </body>

              </html>
