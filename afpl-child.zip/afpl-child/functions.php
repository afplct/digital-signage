<?php
add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_styles', PHP_INT_MAX);
function enqueue_child_theme_styles() {
  $parent_style = 'parent-style';

  wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );

  if ( is_page_template( 'templates/about.php' ) ){
      wp_enqueue_style( 'child-style',
          get_stylesheet_directory_uri() . '/style.css',
          array( $parent_style ),
          wp_get_theme()->get('Version')
      );
  }
}

add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_scripts' );
function enqueue_child_theme_scripts(){
  if ( is_page_template( 'templates/about.php' ) ){
      wp_enqueue_script( 'digital-signage', get_stylesheet_directory_uri() . 'js/digital-signage.js', array( 'jquery' ) );
  }
}

?>
